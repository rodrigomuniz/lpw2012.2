/*
######################################
Verifica se a pessoa é maior de idade
*/
function verificaIdade(){
	var anoNasc = window.prompt("Digite o ano do seu nascimento.","");
	//pega informação do usuário usando window.prompt
	
	if (anoNasc == 0 || anoNasc == null) {//se digitar 0 ou cancelar
			alert("Não vai querer brincar? Informe seu ano de nascimento.");
			verificaIdade();
	} else {//se digitar uma idade
			//converte a string em inteiro
			var anoNasc = parseInt(anoNasc);

			var data = new Date().getFullYear(); //pega o ano do PC

			var idade = data - anoNasc; //calcula a idade da pessoa

			if (idade >=18) {
				document.write("Você tem "+idade+" anos. É maior de idade!")
			} else {
				var ate = 18 - idade; //calcula quantos anos até maior idade
				document.write("Você tem "+idade+" anos. Faltam "+ate+" anos para a maior idade!")
			}
	}
}

/*
######################################
Verifica o dia da semana de uma data
*/
function verificaDiaSemana(){
	var d = window.prompt("Por favor, digite o dia. Ex:(28):","");
	var m = window.prompt("Digite o mês. Ex:(3):","");
	var a = window.prompt("Falta só o ano. Ex:(1984):","");

	var mes = parseInt(m) - 1; //normaliza o mes para o JS
	
	//constroe a data no JS e pega o dia da semana
	var dia = new Date(parseInt(a), mes, parseInt(d)).getDay();
	switch (dia){
		case 0:
		document.write(d +"/"+ m + "/" + a + ": domingo");
		break;
		
		case 1:
		document.write(d +"/"+ m + "/" + a + ": segunda-feira");
		break;
		
		case 2:
		document.write(d +"/"+ m + "/" + a + ": terça-feira");
		break;
		
		case 3:
		document.write("<p class='data'>"+ d +"/"+ m + "/" + a + ": quarta-feira</p>");
		break;
		
		case 4:
		document.write(d +"/"+ m + "/" + a + ": quinta-feira");
		break;
		
		case 5:
		document.write(d +"/"+ m + "/" + a + ": sexta-feira");
		break;
		
		case 6:
		document.write(d +"/"+ m + "/" + a + ": sábado");
		break;
	}
}

/*
##########################################
Verifica o signo segundo o novo horoscopo
*/
function verificaNovoSigno(){
	var d = window.prompt("Por favor, digite o dia do seu nascimento. Ex:(28):","");
	var mes = window.prompt("Falta apenas informar o mês. Ex:(3):","");
	
	var m = parseInt(mes) - 1; //normaliza o mes para o JS

	if((m == 0 && d >= 20) || (m == 1 && d <= 16)){
		document.write("<h1>Capricórnio</h1>");
	}

	if((m == 1 && d >= 17) || (m == 2 && d <=11)){
		document.write("<h1>Aquário</h1>");
	}

	if((m == 2 && d >= 12) || (m == 3 && d <= 18)){
		document.write("<h1>Peixes</h1>");
	}

	if((m == 3 && d >= 19) || (m == 4 && d <= 13)){
		document.write("<h1>Áries</h1>");
	}

	if((m == 4 && d >= 14) || (m == 5 && d <= 21)){
		document.write("<h1>Touro</h1>");
	}

	if((m == 5 && d >= 20) || (m == 6 && d <= 20)){
		document.write("<h1>Gêmeos</h1>");
	}

	if((m == 6 && d >= 21) || (m == 7 && d <= 10)){
		document.write("<h1>Câncer</h1>");
	}

	if((m == 7 && d >= 11) || (m == 8 && d <= 16)){
		document.write("<h1>Leão</h1>");
	}

	if((m == 8 && d >= 17) || (m == 9 && d <= 30)){
		document.write("<h1>Virgem</h1>");
	}

	if((m == 9 && d >= 31) || (m == 10 && d <= 23)){
		document.write("<h1>Libra</h1>");
	}

	if((m == 10 && d >= 24) || (m == 10 && d <= 29)){
		document.write("<h1>Escorpião</h1>");
	}

	if((m == 10 && d >= 30) || (m == 11 && d <= 17)){
		document.write("<h1>Serpentário</h1>");
	}

	if((m == 11 && d >= 18) || (m == 0 && d <= 19)){
		document.write("<h1>Sagitário</h1>");
	}
//tambem pode ser feito com switch case

	document.write("<p>É seu signo segundo o novo horoscopo.</p>");

}

/*
##########################################
Verifica IMC
*/
function verificaIMC(){
	var altura 	= 	window.prompt("Informe sua altura (Exemplo: 1.80).", "");
	var peso 	= 	window.prompt("Agora o seu peso (Exemplo: 75).", "");
	
	//converte os tipos das variaveis
	var a = parseFloat(altura);
	var p = parseFloat(peso);

	var imc = p / Math.pow(a,2); // a ao quadrado ou a * a.

 	//toFixed(2) onde 2 significa o número de casas decimais a serem consideradas do float
	document.write("<h1>Seu IMC é: "+imc.toFixed(2)+"</h1>");
	if(imc < 18.5){
		document.write("<p>Você está abaixo do peso ideal!</p>");
	}
	if(imc >= 18.5 && imc <= 24.9){
		document.write("<p>Parabéns - Você está em seu peso normal!</p>");
	}
	if(imc > 24.9 && imc <= 29.9){
		document.write("<p>Você está acima do seu peso (sobrepeso)! :(</p>");
	}
	if(imc > 29.9 && imc <= 34.9){
		document.write("<p>Cuidado! Obesidade Grau I.</p>");
	}
	if(imc > 34.9 && imc <= 39.9){
		document.write("<p>Cuidado! Obesidade Grau II.</p>");
	} 
	if(imc > 39.9){
		document.write("<p>Cuidado! Obesidade Grau III.</p>");
	}

}

/*
##########################################
Verifica Sorteio
*/
function sorteia(){
//a funcao random() do JavaScript gera um float aleatorio entre 0 a 1. 
//Portanto temos que fazer algumas operacoes 
//Nao ha uma versao que retorne um inteiro
var aleatorio = Math.random();//primeiro guardamos o numero aleatorio
var a50 = aleatorio * 50;//depois multiplicamos por 50, nosso maximo
var num = Math.floor(a50);//usamos floor para arrendondar para baixo para o numero inteiro mais proximo

//exibe o resultado
alert("Resultado: "+num);
}



